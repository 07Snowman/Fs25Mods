ContractServiceProvider = {}

function ContractServiceProvider:loadMap()

    -- Mission generation
    MissionManager.MAX_MISSIONS = 100
	MissionManager.MISSION_GENERATION_INTERVAL = 300000
    MissionManager.MAX_MISSIONS_PER_GENERATION = 50
    MissionManager.MAX_TRIES_PER_GENERATION = 75
	
	-- More Missions acceptable
	MissionManager.hasFarmReachedMissionLimit = Utils.overwrittenFunction(MissionManager.hasFarmReachedMissionLimit, MissionManager.hasFarmReachedMissionLimit);
end

function MissionManager:hasFarmReachedMissionLimit(superFunc, ...)
    return false;
end;

addModEventListener(ContractServiceProvider)